/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author 22abo
 */
public class ClassDescription {
    
    private String coursecode;
    private String description;
    private int seats;
    
    public ClassDescription(String coursecode, String description, int seats){
        this.coursecode = coursecode;
        this.description = description;
        this.seats = seats;
    }
    
    public String getCourseCode(){
        return coursecode;
    }
    public void setCourseCode(String coursecode){
        this.coursecode = coursecode;
    }
    public String getDescription(){
        return description;
    }
    public void setDescription(String description){
        this.description = description;
    }
    public int getSeats(){
        return seats;
    }
    public void setSeats(){
        this.seats = seats;
    }
}



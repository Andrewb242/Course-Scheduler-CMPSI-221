/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author 22abo
 */
public class CourseEntry {
    
    private String coursecode;
    private String description;
    
    public CourseEntry(String coursecode, String description){
        this.coursecode = coursecode;
        this.description = description;
    }
    
    public String getCourseCode(){
        return coursecode;
    }
    public void setCourseCode(String coursecode){
        this.coursecode = coursecode;
    }
    public String getDescription(){
        return description;
    }
    public void setDescription(String description){
        this.description = description;
    }
}

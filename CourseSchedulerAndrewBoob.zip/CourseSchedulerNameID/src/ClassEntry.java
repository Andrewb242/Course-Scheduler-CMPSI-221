/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author 22abo
 */
public class ClassEntry {
    
    private String coursecode;
    private String semester;
    private int seats;
    
    public ClassEntry(String semester, String coursecode, int seats){
        this.semester = semester;
        this.coursecode = coursecode;
        this.seats = seats;
    }
    public String getSemester(){
        return semester;
    }
    public void setSemester(String semester){
        this.semester = semester;
    }
    public String getCourseCode(){
        return coursecode;
    }
    public void setCourseCode(String coursecode){
        this.coursecode = coursecode;
    }
    public int getSeats(){
        return seats;
    }
    public void setSeats(int seats){
        this.seats = seats;
    }

}

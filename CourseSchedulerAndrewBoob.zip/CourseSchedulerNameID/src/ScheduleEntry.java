/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.sql.Timestamp;
import java.util.Calendar;

/**
 *
 * @author 22abo
 */
public class ScheduleEntry {

    private String semester;        
    private String coursecode;
    private String studentID;
    private String status;
    private Timestamp timestamp;
    
    public ScheduleEntry(String semester, String coursecode, String studentID, String status){
        this.semester = semester;
        this.coursecode = coursecode;
        this.studentID = studentID;
        this.status = status;
        this.timestamp = new java.sql.Timestamp(Calendar.getInstance().getTime().getTime());
    }
    public ScheduleEntry(String semester, String coursecode, String studentID, String status, Timestamp timestamp){
        this.semester = semester;
        this.coursecode = coursecode;
        this.studentID = studentID;
        this.status = status;
        this.timestamp = timestamp;
    }

    public String getSemester(){
        return semester;
    }
    public void setSemester(String semester){
        this.semester = semester;
    }
    public String getCourseCode(){
        return coursecode;
    }
    public void setCourseCode(String coursecode){
        this.coursecode = coursecode;
    }
    public String getStudentID(){
        return studentID;
    }
    public void setStudentID(String studentID){
        this.studentID = studentID;
    }
    public String getStatus(){
        return status;
    }
    public void setStatus(String status){
        if (status.equals("S") || status.equals("W")) {
            this.status = status;
        }
    }
    public Timestamp getTimestamp(){
        return timestamp;
    }
    public void setTimeStamp(Timestamp timestamp){
        this.timestamp = timestamp;
    }

}

